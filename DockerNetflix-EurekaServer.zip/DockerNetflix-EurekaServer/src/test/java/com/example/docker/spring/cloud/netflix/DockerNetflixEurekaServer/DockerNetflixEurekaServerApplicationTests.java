package com.example.docker.spring.cloud.netflix.DockerNetflixEurekaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerNetflixEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
