package com.example.docker.spring.cloud.netflix.DockerNetflixEurekaServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerNetflixEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerNetflixEurekaServerApplication.class, args);
	}

}
